package Resources;

public class Anyagok {
}
